describe('Тестування класу Mat за допомогою beforeEach', function () {

  let mat;
  let a = 2;
  let b = 3;
  let sum

  beforeEach(function () {
    mat = new Mat(a++, b++);
    sum = mat.sum();
    console.log(mat)
    console.log(sum)
  });


  it('Підсумовування методом sum(), 2 + 3 = 5', function () {
    expect(mat.sum()).toBe(sum);
  });
  it('Підсумовування методом sum(), 3 + 4 = 7', function () {
    expect(mat.sum()).toBe(sum);
  });
  it('Підсумовування методом sum(), 4 + 5 = 9', function () {
    expect(mat.sum()).toBe(sum);
  });
  it('Підсумовування методом sum(), 5 + 6 = 1', function () {
    expect(mat.sum()).toBe(sum);
  });


  //
  // it('Підсумовування методом sum(), 2 + 3 = 5', function () {
  //   expect(mat.sum()).toBe(5);
  // });
  // it('Підсумовування методом sum(), 3 + 4 = 7', function () {
  //   expect(mat.sum()).toBe(7);
  // });
  // it('Підсумовування методом sum(), 4 + 5 = 9', function () {
  //   expect(mat.sum()).toBe(9);
  // });
  // it('Підсумовування методом sum(), 5 + 6 = 1', function () {
  //   expect(mat.sum()).toBe(11);
  // });

});
