describe('Тестування функції defUpperCase()', function () {

  it('Функція повинна повернути текст у верхньому регістрі', function () {
    const text = 'hello';

    expect(defUpperCase(text)).toBe(text.toUpperCase());
  });

  it('Функція повинна повернути дефолтний текст "DEFAULT TEXT" у верхньому регістрі, за відсутності параметра', function () {

    expect(defUpperCase()).toBe('DEFAULT TEXT');
  });

});
