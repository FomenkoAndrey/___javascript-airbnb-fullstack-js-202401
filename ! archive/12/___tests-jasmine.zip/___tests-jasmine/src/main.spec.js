describe('Тестування класу Mat', function () {

  it('Підсумовування методом sum(), 2 + 3 = 5', function () {
    const mat = new Mat(2, 3);

    expect(mat.sum()).toBe(5);
  });

  it('Віднімання методом sub()', function () {
    expect(new Mat(3, 2).sub()).toBe(1);
    expect(new Mat(3, 3).sub()).toBe(0);
    expect(new Mat(3, 5).sub()).toBe(-2);
  });

  it('Підсумовування методом sum()', function () {
    const mat = new Mat('2', 3);

    expect(mat.sum()).toBe(5);
  });


  it('Підсумовування методом sum()', function () {
    const mat = new Mat(2, '3');

    expect(mat.sum()).toBe(5);
  });


  it('Підсумовування методом sum()', function () {
    const mat = new Mat('2', '3');

    expect(mat.sum()).toBe(5);
  });

});
