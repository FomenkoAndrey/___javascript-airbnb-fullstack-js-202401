import '@css/style.css'

import * as $ from 'jquery'
import Post from '@model/post'
import json from '@/assets/data'
import logo from '@assets/icon-square-big.png'
import xml from '@assets/data.xml'
import csv from '@assets/data.csv'

const post = new Post('Webpack from Zero to Hero', logo)

console.log('Post to string:', post.toString())
$('pre').html(post.toString())

console.log('JSON:', json)
console.log('XML:', xml)
console.log('CSV:', csv)
